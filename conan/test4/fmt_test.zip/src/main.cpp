#include "fmt/core.h"

int main(void) {
fmt::print("Hello, World!\n");
return 0;
}